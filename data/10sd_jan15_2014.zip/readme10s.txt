Readme for dta file of GGDC 10-Sector database (10SD_jan15.dta)
For documentation of the data for each country, see the country files at http://www.ggdc.net/dseries/10-sector.html

If no data value is shown, data for that year, country, industry and variable is not available

Variables:
1	VA - Value added at current national prices (in millions)
2	VA_Q05 - Value added at constant 2005 national prices (in millions)
3	EMP - Persons engaged (in thousands)

Note: if no data is shown for either government services or for community, social and personal services it is included
in the other (this is the case in for example various Latin American countries and for the MENA countries)

